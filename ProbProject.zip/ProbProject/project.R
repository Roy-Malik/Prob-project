# step 1: setting the working directory 
setwd("C:\\Users\\DELL\\Downloads\\ProbProject")  

# this is for checking if our directory is setup or not 
getwd()

# using this to load file our data file in R  
data <- read.csv("dataset.csv")

# this head is use to show data few top rows in terminal 
# head(data)

# this will also show data but in new tab and will show full data 
#View(data)  
#summary(data)

# also show data so some top rows in terminal 
# print(data)

# this tail is use to show data of few rows from buttom in terminal 
# tail(data)

# --------------------- Encoding Categorical Variables ---------------------------

# label encoding for gender (Male = 1, Female = 0)
data$Gender <- ifelse(data$Gender == "Male", 1, 0)

# One-Hot Encoding for 'Occupation'
data <- cbind(data, model.matrix(~Occupation - 1, data = data))  # '-1' removes intercept
data$Occupation <- NULL  # Remove original 'Occupation' column after encoding

# One-Hot Encoding for 'BMI Category'
data <- cbind(data, model.matrix(~BMI.Category - 1, data = data))  # One-Hot Encoding for BMI Category
data$BMI.Category <- NULL  # Remove original 'BMI.Category' column after encoding

# One-Hot Encoding for 'Sleep Disorder'
data <- cbind(data, model.matrix(~Sleep.Disorder - 1, data = data))  # One-Hot Encoding for Sleep Disorder
data$Sleep.Disorder <- NULL  # Remove original 'Sleep.Disorder' column after encoding

#head(data) checking if it is done or not (hot encoding) 

#-------------------------------------------------------------------------------

# ------------------- Data Pre processing (Handling Missing Values) ----------------------

# nrow(data) #checking rows before removing duplicates
# now removing duplicate data 1st 
data <- data[!duplicated(data[, c("Gender", "Age", "Sleep.Duration", "Quality.of.Sleep")]), ]
nrow(data) # checking rows if duplicate data is removed or not 
nrow(data)


# ----------------------- Calculating Mean  Of Data ----------------------------

# now calculating average value of age 
mean_of_age <- mean(data$Age, na.rm = TRUE)

# replacing missing values in age column with the mean value
data$Age[is.na(data$Age)] <- mean_of_age
print(mean_of_age)

# now calculating average value of sleep duration
mean_sleep_duration <- mean(data$Sleep.Duration, na.rm = TRUE)
data$Sleep.Duration[is.na(data$Sleep.Duration)] <- mean_sleep_duration
print(mean_sleep_duration)

# now calculating average value of quality of sleep
mean_quality_of_sleep <- mean(data$Quality.of.Sleep, na.rm = TRUE)
data$Quality.of.Sleep[is.na(data$Quality.of.Sleep)] <- mean_quality_of_sleep
print(mean_quality_of_sleep)

# now calculating average value of physical activity level
mean_physical_activity <- mean(data$Physical.Activity.Level, na.rm = TRUE)
data$Physical.Activity.Level[is.na(data$Physical.Activity.Level)] <- mean_physical_activity
print(mean_physical_activity)

# now calculating average value of stress level
mean_stress_level <- mean(data$Stress.Level, na.rm = TRUE)
data$Stress.Level[is.na(data$Stress.Level)] <- mean_stress_level
print(mean_stress_level)

# now calculating average value of heart rate
mean_heart_rate <- mean(data$Heart.Rate, na.rm = TRUE)
data$Heart.Rate[is.na(data$Heart.Rate)] <- mean_heart_rate
print(mean_heart_rate)

# now calculating average value of daily steps
mean_daily_steps <- mean(data$Daily.Steps, na.rm = TRUE)
data$Daily.Steps[is.na(data$Daily.Steps)] <- mean_daily_steps
print(mean_daily_steps)

#----------------------------------------------------------------------------

# ----------------------- Calculating Median  Of Data ----------------------------

# Now calculating median value of age
median_age <- median(data$Age, na.rm = TRUE)
print(median_age)

# Now calculating median value of sleep duration
median_sleep_duration <- median(data$Sleep.Duration, na.rm = TRUE)
print(median_sleep_duration)

# Now calculating median value of quality of sleep
median_quality_of_sleep <- median(data$Quality.of.Sleep, na.rm = TRUE)
print(median_quality_of_sleep)

# Now calculating median value of physical activity level
median_physical_activity <- median(data$Physical.Activity.Level, na.rm = TRUE)
print(median_physical_activity)

# Now calculating median value of stress level
median_stress_level <- median(data$Stress.Level, na.rm = TRUE)
print(median_stress_level)

# Now calculating median value of heart rate
median_heart_rate <- median(data$Heart.Rate, na.rm = TRUE)
print(median_heart_rate)

# Now calculating median value of daily steps
median_daily_steps <- median(data$Daily.Steps, na.rm = TRUE)
print(median_daily_steps)

#---------------------------------------------------------------------

# ----------------------- Calculating Mode  Of Data ----------------------------

# Function to calculate mode
getmode <- function(v) {
  uniqv <- unique(v)
  uniqv[which.max(tabulate(match(v, uniqv)))]
}

# Now calculating mode value of age
mode_age <- getmode(data$Age)
print(mode_age)

# Now calculating mode value of sleep duration
mode_sleep_duration <- getmode(data$Sleep.Duration)
print(mode_sleep_duration)

# Now calculating mode value of quality of sleep
mode_quality_of_sleep <- getmode(data$Quality.of.Sleep)
print(mode_quality_of_sleep)

# Now calculating mode value of physical activity level
mode_physical_activity <- getmode(data$Physical.Activity.Level)
print(mode_physical_activity)

# Now calculating mode value of stress level
mode_stress_level <- getmode(data$Stress.Level)
print(mode_stress_level)

# Now calculating mode value of heart rate
mode_heart_rate <- getmode(data$Heart.Rate)
print(mode_heart_rate)

# Now calculating mode value of daily steps
mode_daily_steps <- getmode(data$Daily.Steps)
print(mode_daily_steps)

#--------------------------------------------------------------------

# ----------------------- Calculating Standard Deviation and Variance  ----------------------------

# Now calculating standard deviation and variance of age
sd_age <- sd(data$Age, na.rm = TRUE)
var_age <- var(data$Age, na.rm = TRUE)
print(sd_age)
print(var_age)

# Now calculating standard deviation and variance of sleep duration
sd_sleep_duration <- sd(data$Sleep.Duration, na.rm = TRUE)
var_sleep_duration <- var(data$Sleep.Duration, na.rm = TRUE)
print(sd_sleep_duration)
print(var_sleep_duration)

# Now calculating standard deviation and variance of quality of sleep
sd_quality_of_sleep <- sd(data$Quality.of.Sleep, na.rm = TRUE)
var_quality_of_sleep <- var(data$Quality.of.Sleep, na.rm = TRUE)
print(sd_quality_of_sleep)
print(var_quality_of_sleep)

# Now calculating standard deviation and variance of physical activity level
sd_physical_activity <- sd(data$Physical.Activity.Level, na.rm = TRUE)
var_physical_activity <- var(data$Physical.Activity.Level, na.rm = TRUE)
print(sd_physical_activity)
print(var_physical_activity)

# Now calculating standard deviation and variance of stress level
sd_stress_level <- sd(data$Stress.Level, na.rm = TRUE)
var_stress_level <- var(data$Stress.Level, na.rm = TRUE)
print(sd_stress_level)
print(var_stress_level)

# Now calculating standard deviation and variance of heart rate
sd_heart_rate <- sd(data$Heart.Rate, na.rm = TRUE)
var_heart_rate <- var(data$Heart.Rate, na.rm = TRUE)
print(sd_heart_rate)
print(var_heart_rate)

# Now calculating standard deviation and variance of daily steps
sd_daily_steps <- sd(data$Daily.Steps, na.rm = TRUE)
var_daily_steps <- var(data$Daily.Steps, na.rm = TRUE)
print(sd_daily_steps)
print(var_daily_steps)

#-------------------------------------------------------


# ---------------------- Outlier Detection using IQR Method ----------------------
# Function to detect and remove outliers using IQR method
remove_outliers <- function(df, columns) {
  for (col in columns) {
    Q1 <- quantile(df[[col]], 0.25, na.rm = TRUE)
    Q3 <- quantile(df[[col]], 0.75, na.rm = TRUE)
    IQR <- Q3 - Q1
    lower_bound <- Q1 - 1.5 * IQR
    upper_bound <- Q3 + 1.5 * IQR
    
    # Removing outliers
    df <- df[df[[col]] >= lower_bound & df[[col]] <= upper_bound, ]
    cat("Outliers detected and removed in column:", col, "\n")
  }
  return(df)
}

# list of numerical columns to process
numerical_columns <- c('Age', 'Sleep.Duration', 'Physical.Activity.Level', 
                       'Heart.Rate', 'Stress.Level', 'Daily.Steps')

# Apply outlier removal function
data <- remove_outliers(data, numerical_columns)


#head(data) # as changed data of age ID 1 to 500 and checking and yeah it is romoved

#------------------------------------------------------------------------------


# ---------------------- Feature Scaling (Z-Score and Min-Max) ----------------------
# Standardization (Z-score normalization)
standardize_features <- function(df, columns) {
  for (col in columns) {
    mean_val <- mean(df[[col]], na.rm = TRUE)
    sd_val <- sd(df[[col]], na.rm = TRUE)
    df[[col]] <- (df[[col]] - mean_val) / sd_val
  }
  cat("Feature scaling applied (Z-score normalization).\n")
  return(df)
}

# Min-Max Normalization
normalize_features <- function(df, columns) {
  for (col in columns) {
    min_val <- min(df[[col]], na.rm = TRUE)
    max_val <- max(df[[col]], na.rm = TRUE)
    df[[col]] <- (df[[col]] - min_val) / (max_val - min_val)
  }
  cat("Feature scaling applied (Min-Max normalization).\n")
  return(df)
}

# Apply standardization (Z-score) and normalization (Min-Max)
data <- standardize_features(data, numerical_columns)
data <- normalize_features(data, numerical_columns)

# Display the cleaned and scaled data
cat("\nCleaned and Scaled Data:\n")
head(data)  # Display first 6 rows after outlier removal and scaling

#-------------------------------------------------------------------- 


#-------------------------- Task5. Exploratory Data Analysis (EDA)----------


# Check the column names in the dataset
colnames(data)

# ------------------- Bar Charts ----------------------
library(ggplot2)

# 1. Convert one-hot encoded Occupation columns to single column
occupation_cols <- grep("^Occupation", names(data), value = TRUE)
data$Occupation <- apply(data[occupation_cols], 1, function(row) {
  if (all(row == 0)) return(NA)
  gsub("^Occupation", "", occupation_cols[which.max(row)])
})

# 2. Convert one-hot encoded BMI Category columns to single column
bmi_cols <- grep("^BMI.Category", names(data), value = TRUE)
data$BMI.Category <- apply(data[bmi_cols], 1, function(row) {
  if (all(row == 0)) return(NA)
  gsub("^BMI.Category", "", bmi_cols[which.max(row)])
})

# 3. Convert one-hot encoded Sleep Disorder columns to single column
sleep_cols <- grep("^Sleep.Disorder", names(data), value = TRUE)
data$Sleep.Disorder <- apply(data[sleep_cols], 1, function(row) {
  if (all(row == 0)) return(NA)
  gsub("^Sleep.Disorder", "", sleep_cols[which.max(row)])
})

# 4. Plot: Occupation
ggplot(data, aes(x = Occupation)) +
  geom_bar(fill = "steelblue") +
  labs(title = "Occupation vs Count of People", x = "Occupation", y = "Count") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# 5. Plot: BMI Category
ggplot(data, aes(x = BMI.Category)) +
  geom_bar(fill = "darkgreen") +
  labs(title = "BMI Category vs Count of People", x = "BMI Category", y = "Count") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# 6. Plot: Sleep Disorder
ggplot(data, aes(x = Sleep.Disorder)) +
  geom_bar(fill = "tomato") +
  labs(title = "Sleep Disorder vs Count of People", x = "Sleep Disorder", y = "Count") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


#------------------------------------------------------------------

#--------------------------------- PIE CHART -------------------
library(dplyr)
# 1. Sleep Disorder Distribution
sleep_counts <- data %>%
  count(Sleep.Disorder) %>%
  mutate(Percent = round(100 * n / sum(n), 1),
         Label = paste0(Sleep.Disorder, ": ", n, " (", Percent, "%)"))

ggplot(sleep_counts, aes(x = "", y = n, fill = Sleep.Disorder)) +
  geom_bar(stat = "identity", width = 1, color = "white") +
  coord_polar("y") +
  geom_text(aes(label = Label), 
            position = position_stack(vjust = 0.5), size = 4) +
  labs(title = "1. Sleep Disorder Distribution",
       x = NULL, y = NULL) +
  theme_void() +
  theme(legend.position = "none")


# 2. BMI Category Distribution

bmi_counts <- data %>%
  count(BMI.Category) %>%
  mutate(Percent = round(100 * n / sum(n), 1),
         Label = paste0(BMI.Category, ": ", n, " (", Percent, "%)"))

ggplot(bmi_counts, aes(x = "", y = n, fill = BMI.Category)) +
  geom_bar(stat = "identity", width = 1, color = "white") +
  coord_polar("y") +
  geom_text(aes(label = Label),
            position = position_stack(vjust = 0.5), size = 4) +
  labs(title = "2. BMI Category Distribution",
       x = NULL, y = NULL) +
  theme_void() +
  theme(legend.position = "none")

#---------------------------------------------------------

#------------------------HISTOGRAM-------------------------------


ggplot(data, aes(x = Sleep.Duration)) +
  geom_histogram(binwidth = 0.1, fill = "steelblue", color = "black", alpha = 0.8) +
  labs(title = "Histogram of Sleep Duration",
       x = "Sleep Duration (normalized)",
       y = "Frequency") +
  theme_minimal()

# Histogram of Stress Level
ggplot(data, aes(x = Stress.Level)) +
  geom_histogram(binwidth = 0.1, fill = "tomato", color = "black", alpha = 0.8) +
  labs(title = "Histogram of Stress Level",
       x = "Stress Level (normalized)",
       y = "Frequency") +
  theme_minimal()

# for age 
ggplot(data, aes(x = Age)) +
  geom_histogram(bins = 30, fill = "skyblue", color = "black", alpha = 0.7) +
  labs(title = "Histogram of Age", x = "Age", y = "Frequency") +
  theme_minimal()

# for gender
ggplot(data, aes(x = Gender)) +
  geom_histogram(bins = 30, fill = "skyblue", color = "black", alpha = 0.7) +
  labs(title = "Histogram of Age", x = "Age", y = "Frequency") +
  theme_minimal()

#----------------------------------------------------------------
# Install and load plotly if not already
if (!require("plotly")) install.packages("plotly", dependencies = TRUE)
library(plotly)

# Select numeric columns for outlier detection
numeric_vars <- c("Sleep.Duration", "Stress.Level", "Heart.Rate", 
                  "Daily.Steps", "Physical.Activity.Level", "Age")

# Melt the data to long format for grouped boxplot
library(reshape2)
long_data <- melt(data[, numeric_vars])

# Create interactive boxplot
fig <- plot_ly(
  data = long_data,
  y = ~value,
  color = ~variable,
  type = "box",
  boxpoints = "outliers",  # explicitly show outliers
  jitter = 0.3
)

fig <- fig %>% layout(
  title = "Interactive Boxplot for Outlier Detection",
  yaxis = list(title = "Value"),
  xaxis = list(title = "Variable")
)

fig


#-------------------------Distribution Plot-------------------------------------
  
  # 1. Distribution Plot for Age (after cleaning outliers)
  ggplot(data, aes(x = Age)) +
  geom_histogram(aes(y = ..density..), bins = 30, fill = "skyblue", color = "black", alpha = 0.7) +
  geom_density(color = "red", size = 1) +
  labs(title = "Distribution of Age", x = "Age", y = "Density") +
  theme_minimal()

# 2. Distribution Plot for Sleep Duration (after cleaning outliers)
ggplot(data, aes(x = Sleep.Duration)) +
  geom_histogram(aes(y = ..density..), bins = 30, fill = "lightgreen", color = "black", alpha = 0.7) +
  geom_density(color = "red", size = 1) +
  labs(title = "Distribution of Sleep Duration", x = "Sleep Duration (hours)", y = "Density") +
  theme_minimal()

# 3. Distribution Plot for Heart Rate (after cleaning outliers)
ggplot(data, aes(x = Heart.Rate)) +
  geom_histogram(aes(y = ..density..), bins = 30, fill = "lightcoral", color = "black", alpha = 0.7) +
  geom_density(color = "red", size = 1) +
  labs(title = "Distribution of Heart Rate", x = "Heart Rate (beats per minute)", y = "Density") +
  theme_minimal()

# 4. Distribution Plot for Daily Steps (after cleaning outliers)
ggplot(data, aes(x = Daily.Steps)) +
  geom_histogram(aes(y = ..density..), bins = 30, fill = "lightblue", color = "black", alpha = 0.7) +
  geom_density(color = "red", size = 1) +
  labs(title = "Distribution of Daily Steps", x = "Daily Steps", y = "Density") +
  theme_minimal()


#--------------------------------------------------------------

#---------------------------Scatter Plot-----------------------------------
  
  
  # Scatter Plot for Physical Activity Level vs Stress Level
  ggplot(data, aes(x = Physical.Activity.Level, y = Stress.Level)) +
  geom_point(color = "blue") + 
  labs(title = "Physical Activity Level vs Stress Level",
       x = "Physical Activity Level",
       y = "Stress Level") +
  theme_minimal()

# Scatter Plot for Sleep Duration vs Stress Level
ggplot(data, aes(x = Sleep.Duration, y = Stress.Level)) +
  geom_point(color = "red") + 
  labs(title = "Sleep Duration vs Stress Level",
       x = "Sleep Duration",
       y = "Stress Level") +
  theme_minimal()

# Scatter Plot for Heart Rate vs Daily Steps
ggplot(data, aes(x = Heart.Rate, y = Daily.Steps)) +
  geom_point(color = "green") + 
  labs(title = "Heart Rate vs Daily Steps",
       x = "Heart Rate",
       y = "Daily Steps") +
  theme_minimal()


#--------------------------------------------------------------

  
  
#----------------------- Density Plot (KDE) ---------------------------

# Loading necessary library
library(ggplot2)

# 1. Sleep Duration by Sleep Disorder
ggplot(data, aes(x = Sleep.Duration, fill = Sleep.Disorder)) +
  geom_density(alpha = 0.6) +
  labs(title = "Density Plot of Sleep Duration by Sleep Disorder", x = "Sleep Duration", y = "Density") +
  theme_minimal()

# 2. Heart Rate by Gender
ggplot(data, aes(x = Heart.Rate, fill = factor(Gender))) +
  geom_density(alpha = 0.6) +
  labs(title = "Density Plot of Heart Rate by Gender", x = "Heart Rate", y = "Density") +
  theme_minimal()

# 3. Stress Level by BMI Category
ggplot(data, aes(x = Stress.Level, fill = BMI.Category)) +
  geom_density(alpha = 0.6) +
  labs(title = "Density Plot of Stress Level by BMI Category", x = "Stress Level", y = "Density") +
  theme_minimal()

#--------------------------------------------------------------

# ------------------- Pair Plot ----------------------
if (!require("GGally")) install.packages("GGally")

# Load the package
library(GGally)

# Select relevant numeric columns for the pair plot
selected_vars <- data[, c("Sleep.Duration", "Stress.Level", "Heart.Rate", "Daily.Steps", "Age")]

# Create the pair plot
ggpairs(selected_vars, 
        title = "Pair Plot of Selected Numeric Variables",
        lower = list(continuous = "smooth"),  # Add smoother in lower panels
        diag = list(continuous = "barDiag"),  # Histogram on diagonals
        upper = list(continuous = "cor"))     # Correlation on upper panels


#------------------------------------------------------------------------

# ------------------Heatmap--------------------------------------

# Install required libraries if not already installed
if (!require("heatmaply")) install.packages("heatmaply", dependencies = TRUE)
if (!require("plotly")) install.packages("plotly", dependencies = TRUE)

library(heatmaply)

# Select numeric columns
numeric_vars <- c("Sleep.Duration", "Stress.Level", "Heart.Rate", 
                  "Daily.Steps", "Physical.Activity.Level", "Age")

# Extract and clean
cor_data <- na.omit(data[, numeric_vars])

# Compute correlation matrix
cor_matrix <- cor(cor_data)

# Plot interactive heatmap
heatmaply(
  cor_matrix,
  k_col = 2, # cluster columns (optional)
  k_row = 2, # cluster rows (optional)
  main = "Interactive Correlation Heatmap",
  xlab = "Variables",
  ylab = "Variables",
  colors = colorRampPalette(c("blue", "white", "red"))(200),
  labCol = colnames(cor_matrix),
  labRow = rownames(cor_matrix)
)

# -------------------------------------------------------------------------
# --------------------- Step 6: Interactive Visualization ---------------------
# Install and load necessary library
if (!require("plotly")) install.packages("plotly", dependencies=TRUE)
library(plotly)

# Remove missing values
clean_data <- na.omit(data)
# Clean BMI.Category to avoid duplicates
data$BMI.Category <- trimws(tolower(data$BMI.Category))
data$BMI.Category <- tools::toTitleCase(data$BMI.Category)

# Create interactive scatter plot
fig <- plot_ly(clean_data, x = ~Sleep.Duration, y = ~Stress.Level, type = 'scatter', mode = 'markers',
               color = ~BMI.Category, text = ~Occupation)
fig <- fig %>% layout(title = 'Sleep Duration vs Stress Level by BMI Category',
                      xaxis = list(title = 'Sleep Duration'),
                      yaxis = list(title = 'Stress Level'))
fig

# --------------------- Step 7: Statistical Modeling & Inference ---------------------

# Correlation matrix
cor_matrix <- cor(clean_data[, c("Sleep.Duration", "Stress.Level", "Daily.Steps", 
                                 "Physical.Activity.Level", "Quality.of.Sleep", "Heart.Rate")])
print(cor_matrix)

# Simple Linear Regression (SLR): Stress Level ~ Sleep Duration
slr_model <- lm(Stress.Level ~ Sleep.Duration, data = clean_data)
summary(slr_model)

# Multiple Linear Regression (MLR): Stress Level ~ Sleep + Activity + Quality + Heart Rate
mlr_model <- lm(Stress.Level ~ Sleep.Duration + Physical.Activity.Level + 
                  Quality.of.Sleep + Heart.Rate, data = clean_data)
summary(mlr_model)

# --------------------- Step 8: Conclusion ---------------------
cat("Conclusion:\n")
cat("This analysis explored the relationship between sleep-related behaviors and stress levels.\n")
cat("Key findings from the correlation matrix indicate that Sleep Duration and Quality of Sleep are inversely related to Stress Level, suggesting that better sleep may contribute to lower stress.\n")
cat("The Simple Linear Regression model confirmed that Sleep Duration alone has a statistically significant impact on Stress Level, though with moderate explanatory power.\n")
cat("The Multiple Linear Regression model improved this prediction by incorporating additional predictors such as Physical Activity Level, Quality of Sleep, and Heart Rate — all contributing meaningfully to stress variation.\n")
cat("The interactive scatter plot provides a visual depiction of how BMI category influences the relationship between sleep and stress, revealing observable clustering patterns.\n\n")

cat("Limitations:\n")
cat("- The dataset contains some anomalies (e.g., unrealistic age values like 500), which may bias results.\n")
cat("- Missing values were removed, potentially reducing sample size and introducing selection bias.\n")
cat("- Categorical encoding was applied, but further feature engineering could improve model performance.\n\n")

cat("Future recommendations include collecting more robust and clean data, exploring non-linear relationships (e.g., polynomial regression), and incorporating time-based or longitudinal data to better understand sleep-stress dynamics over time.\n")
